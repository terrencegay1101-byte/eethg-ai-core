# EETHG AI CORE Architecture

## 1. Human Oversight
- Owns policy approval, risk acceptance, exception handling, and final authorization for consequential actions.
- Can pause any workflow, revoke an approval, and request an audit.
- Public content remains draft until a named human reviewer approves the exact version and destination.

## 2. EETHG Unified Studio
- Operator console for requests, status, approvals, audit trails, and deployment readiness.
- Displays each agent and platform connector separately.
- Shows connector status as: unavailable, not connected, connected/read-only, connected/write-enabled, or action completed.

## 3. AI Core Orchestrator
- Classifies incoming work and routes only to authorized agents.
- Applies shared governance checks before and after agent execution.
- Maintains correlation IDs and records which agent, model, connector, and policy version participated.
- Does not grant itself permissions or bypass human approval.

## 4. Domain agents
- Governance AI: policy mapping, compliance research, risk review; never represents a legal determination.
- Education AI: curriculum, explanations, skills maps; human educator review for consequential learner decisions.
- Commerce AI: business analysis and workflows; no transactions, financial commitments, or offers without explicit approval.
- Workforce AI: skills and workflow support; no autonomous hiring, firing, compensation, or disciplinary decisions.
- Future agents inherit the same contract and must pass governance tests before activation.

## 5. Shared layers
- Knowledge: source-linked facts, definitions, provenance, freshness, confidence, and conflict handling.
- Governance: policy registry, permissions, consent, safety checks, retention, and escalation.
- Analytics: approved metrics, quality monitoring, fairness checks, and operational trends.
- Reporting: audit events, user-facing explanations, status reports, and exportable logs.
- Memory: user-approved durable preferences and project context; sensitive data excluded unless specifically permitted and necessary.

## 6. Standard request lifecycle
1. Human submits a request.
2. Orchestrator classifies domain, sensitivity, destination, and required permissions.
3. Governance layer checks consent, access, and risk.
4. Agent performs a bounded task and cites its inputs.
5. Output is returned as a draft with provenance and uncertainty.
6. Human reviews and approves any external action.
7. Connector executes only the approved action.
8. Reporting layer records result, actor, timestamp, target, and rollback path.
