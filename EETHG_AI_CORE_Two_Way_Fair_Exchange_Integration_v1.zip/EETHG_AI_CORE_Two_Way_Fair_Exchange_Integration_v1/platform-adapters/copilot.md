# Microsoft Copilot adapter
- Share the architecture and exchange envelope as a reviewed handoff document or prompt.
- Do not claim Copilot is connected to the EETHG orchestrator unless a supported connector/API is configured and tested.
- Preserve human approval and source provenance when transferring context.
