# GitHub adapter
- Use a dedicated repository or approved existing repository.
- Work on a feature branch; commit package files; open a pull request for review.
- Protect the default branch and require review/checks before merge.
- Use GitHub Actions only with minimal repository permissions and protected secrets.
- Do not overwrite or consolidate existing EETHG/BSX repositories without explicit repository-specific approval.
