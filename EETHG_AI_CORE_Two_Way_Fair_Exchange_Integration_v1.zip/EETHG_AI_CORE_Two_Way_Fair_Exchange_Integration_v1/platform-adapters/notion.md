# Notion adapter
- Store architecture, governance charter, agent registry, decisions, and deployment checklist.
- Use separate databases for Agents, Integrations, Approvals, and Audit Events if the workspace supports them.
- Suggested fields: Name, Status, Owner, Scope, Risk Level, Last Reviewed, Evidence URL, Approval Record.
- Avoid placing credentials or restricted personal data in pages.
- Writes should target a user-selected page/database and be verified by reading back the result.
