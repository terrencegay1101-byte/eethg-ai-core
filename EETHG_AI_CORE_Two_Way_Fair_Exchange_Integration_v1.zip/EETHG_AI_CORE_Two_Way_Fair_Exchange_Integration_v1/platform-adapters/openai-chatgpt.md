# OpenAI / ChatGPT adapter
- Use the portable exchange envelope for agent requests and results.
- Keep API keys in server-side secret storage; never place keys in prompts, repositories, browser code, or public files.
- Enforce tool allowlists and per-agent scopes.
- Record model identifier, policy version, tool calls, and human approval references.
- Treat model output as a draft; human approval gates external effects.
