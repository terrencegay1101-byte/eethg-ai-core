# Vercel adapter
- Host the Unified Studio UI and API only after a selected project/repository is verified.
- Deploy preview first; test access controls, consent gates, audit events, and rollback.
- Keep secrets in Vercel environment variables with environment-specific scopes.
- Do not attach a custom domain or promote to production until the exact deployment and domain are approved.
