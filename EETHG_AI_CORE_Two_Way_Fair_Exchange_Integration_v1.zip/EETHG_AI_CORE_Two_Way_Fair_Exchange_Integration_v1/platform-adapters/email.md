# Outlook and Gmail adapters
- Default to draft-only.
- Before sending, show exact To/Cc/Bcc, subject, body, attachments, and sending account for approval.
- Do not infer recipients from organization names or send bulk notices by default.
- Outlook tools are available in this workspace; Gmail must be connected before mailbox actions can be performed.
