# Two-Way Fair Exchange Charter

## Purpose
Define a consent-based, transparent, and accountable exchange between people and EETHG AI services.

## Principles
- Mutual value: describe the expected benefit to both the requester and the system/operator.
- Informed consent: explain data requested, purpose, access, retention, and any external destination.
- Human primacy: humans decide policy, consequential outcomes, and external publication.
- Data minimization: collect only what the task requires.
- Attribution: preserve source links, authorship, licenses, and provenance.
- Non-exploitation: do not imply that access to a person's data, labor, or content is required beyond the stated task.
- Contestability: provide a route to correct, challenge, or withdraw where technically and legally possible.

## Required disclosure before an exchange
1. What the person provides.
2. What the AI will do.
3. What output or service the person receives.
4. Which services or people can access the data.
5. Whether data leaves the current platform.
6. Retention and deletion constraints.
7. Whether the action is reversible.

## Approval levels
- Level 0 — internal drafting: no external side effect.
- Level 1 — read-only connector access: requires user-authorized connection and least-privilege scope.
- Level 2 — reversible workspace write: requires approval of destination and content.
- Level 3 — external communication/publication/account change: requires approval of exact content, recipient/audience, and destination immediately before execution.
- Level 4 — financial, legal, employment, identity, or other high-impact action: human expert review and applicable legal/regulatory controls; AI must not make the decision autonomously.

## Audit minimum
Record request ID, human requester, agent, policy version, data sources, destination, approval, execution result, timestamp, and rollback/reference link. Do not log secrets or unnecessary personal data.
