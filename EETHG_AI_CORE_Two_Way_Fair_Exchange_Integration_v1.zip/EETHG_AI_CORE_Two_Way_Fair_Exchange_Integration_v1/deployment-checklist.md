# Deployment Checklist

## Stage 0 — Confirm scope
- [ ] Select authoritative GitHub repository and branch.
- [ ] Select Notion workspace destination.
- [ ] Select Vercel team/project and staging domain.
- [ ] Identify exact Google services and Copilot handoff method.
- [ ] Confirm which email account is for drafts and which is for sending.
- [ ] Define agent owners, data classifications, retention, and incident contact.

## Stage 1 — Foundation
- [ ] Commit architecture and schemas to a feature branch.
- [ ] Create Notion governance/agent/integration records.
- [ ] Implement authentication, role-based access, consent registry, and audit events.
- [ ] Add automated schema validation and policy tests.

## Stage 2 — Agent integration
- [ ] Register Governance, Education, Commerce, and Workforce agents.
- [ ] Add routing allowlists and bounded tool permissions.
- [ ] Add provenance and confidence metadata.
- [ ] Test cross-domain workflows with synthetic data only.

## Stage 3 — Platform adapters
- [ ] Configure OpenAI runtime securely.
- [ ] Configure Notion read/write scopes.
- [ ] Configure GitHub branch/PR workflow.
- [ ] Configure Vercel preview deployment.
- [ ] Configure Copilot and Google handoffs only after supported access is verified.
- [ ] Connect Gmail if desired; verify Outlook profile and mailbox scope.

## Stage 4 — Release gate
- [ ] Human review of exact release candidate.
- [ ] Security/privacy review and threat model.
- [ ] Accessibility and abuse testing.
- [ ] Confirm public claims distinguish deployed features from proposed capabilities.
- [ ] Approve exact domain, audience, and deployment.
- [ ] Publish release notes and rollback plan.

## Completion criteria
A platform is “integrated” only after its connector is authorized, the adapter passes tests, audit evidence exists, and the human owner signs off. A plan, draft, or repository file alone is not proof of live integration.
