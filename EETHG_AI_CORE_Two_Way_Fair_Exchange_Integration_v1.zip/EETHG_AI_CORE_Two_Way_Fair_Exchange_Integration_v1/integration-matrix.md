# Platform Integration Matrix

| Platform | Intended EETHG role | Practical integration path | Current boundary in this workspace |
|---|---|---|---|
| OpenAI / ChatGPT | Agent runtime, model interface, orchestration support | OpenAI API or approved ChatGPT app workflows; keep keys server-side | OpenAI developer tooling is available; no EETHG API key or deployed agent is established by this package |
| Notion | Human-readable knowledge base, governance docs, task tracking | Create reviewed pages/databases; link source records and approval status | Notion tools are available; a destination page/database has not been selected or modified here |
| Vercel | Hosting, previews, deployment and public interface | Deploy from a selected Git repository; staging first; production promotion after review | Vercel tools are available; no project/domain/deployment was changed by this package |
| GitHub | Version control, issue tracking, review and release history | Store specs and adapter code; branch + pull request; required review before merge | GitHub tools are available; target repository/branch has not been selected |
| Microsoft Copilot | Separate assistant endpoint / human-reviewed handoff | Use a documented prompt and portable JSON envelope; use supported Microsoft connectors/API only where authorized | No Copilot account connector or agent endpoint is established here |
| Google | Documents, identity, storage, search or other Google services as authorized | Use Google APIs/connectors with narrowly scoped OAuth consent | Google Drive connector appears unavailable/disabled in the discovered catalog; no Google account connection is assumed |
| Bing | External search and source discovery | Search results are treated as untrusted evidence; retain URLs, dates, and citations | Public web search is available in this chat; no Bing account or publishing integration is implied |
| Outlook Email | Human-reviewed correspondence and notifications | Draft first; send only after explicit approval of recipients and final content | Outlook Email tools are available; no email is sent by this package |
| Gmail | Human-reviewed correspondence and notifications | Connect Gmail; draft first; send only after explicit approval | Gmail connection has been suggested but is not confirmed connected |

## Adapter rules
- Every adapter must identify its authenticated principal, scopes, data accessed, write capabilities, and retention.
- Search/read operations must be separated from write/publish/send operations.
- External write operations must require a fresh approval record bound to the exact payload and destination.
- Platform terms, API limits, and connector permissions override this illustrative design.
